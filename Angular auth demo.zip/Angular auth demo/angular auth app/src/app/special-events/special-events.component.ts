import { Component, OnInit } from '@angular/core';
import { EventsService } from '../events.service';
import { HttpErrorResponse } from '../../../node_modules/@angular/common/http';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-special-events',
  templateUrl: './special-events.component.html',
  styleUrls: ['./special-events.component.css']
})
export class SpecialEventsComponent implements OnInit {

  specialevents =[]
  constructor(private eventsService:EventsService, private router:Router) { }

  ngOnInit() {
    this.getSpecialData();
  }

  getSpecialData() {
    this.eventsService.getSpecialEvents()
         .subscribe( 
         res => this.specialevents = res,
         err => {
           if(err instanceof HttpErrorResponse){
             if(err.status === 401){
               this.router.navigate(['/login'])
             }
           }
         }
         )
  }

}
