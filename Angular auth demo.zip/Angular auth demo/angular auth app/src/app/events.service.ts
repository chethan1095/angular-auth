import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http"

@Injectable({
  providedIn: 'root'
})
export class EventsService { 

    private _eventsApi = "http://localhost:8500/api/events";
    private _specialApi = "http://localhost:8500/api/special";

    constructor(private http: HttpClient) { }

   getEvents() {
       return this.http.get<any>(this._eventsApi);
   }

   getSpecialEvents() {
       return this.http.get<any>(this._specialApi);
   }
}